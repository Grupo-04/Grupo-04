package projeto.api.unlock.artistaquery.controle;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import projeto.api.unlock.artistaquery.entidade.Estabelecimento;
import projeto.api.unlock.artistaquery.repositorio.EstabelecimentoRepository;

import java.util.List;
import java.util.Random;

@RestController
@RequestMapping("/estabelecimentos")
public class EstabelecimentoController {

        @Autowired
        private EstabelecimentoRepository repository;

        private List<Estabelecimento> estabelecimentos;

        @PostMapping
        public ResponseEntity postEstabelecimento(
                @RequestBody Estabelecimento novoEstabelecimento) {
            repository.save(novoEstabelecimento);
            return ResponseEntity.status(201).build();
        }

        @GetMapping
        public ResponseEntity getEstabelecimento() {
            estabelecimentos = repository.findAll();
            Random gerador = new Random();
            if (estabelecimentos.isEmpty()) {
                return ResponseEntity.status(204).build();
            }

            return ResponseEntity.status(200).body(estabelecimentos.get(gerador.nextInt(estabelecimentos.size())));
        }
    }

