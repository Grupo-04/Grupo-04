package projeto.api.unlock.artistaquery.entidade;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Estabelecimento {

    @Id  // do pacote javax.persistence
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String cnpj;
    private String nomeEstabelecimento;
    private String telefoneEstabelecimento;
    private String emailEstabelecimento;
    private String senhaEstabelecimento;
//    private String horarioAtendimento;
//    private String tipoEstabelecmento;
//    private Integer quantidadeArtistasSuportados;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public String getNomeEstabelecimento() {
        return nomeEstabelecimento;
    }

    public void setNomeEstabelecimento(String nomeEstabelecimento) {
        this.nomeEstabelecimento = nomeEstabelecimento;
    }

    public String getTelefoneEstabelecimento() {
        return telefoneEstabelecimento;
    }

    public void setTelefoneEstabelecimento(String telefoneEstabelecimento) {
        this.telefoneEstabelecimento = telefoneEstabelecimento;
    }

    public String getEmailEstabelecimento() {
        return emailEstabelecimento;
    }

    public void setEmailEstabelecimento(String emailEstabelecimento) {
        this.emailEstabelecimento = emailEstabelecimento;
    }

    public void setSenhaEstabelecimento(String senhaEstabelecimento) {
        this.senhaEstabelecimento = senhaEstabelecimento;
    }
}

