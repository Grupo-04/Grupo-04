package projeto.api.unlock.artistaquery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArtistaQueryApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArtistaQueryApplication.class, args);
	}

}
