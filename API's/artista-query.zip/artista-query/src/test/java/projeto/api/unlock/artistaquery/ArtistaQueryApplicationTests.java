package projeto.api.unlock.artistaquery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArtistaQueryApplicationTests {

	@Test
	void contextLoads() {
	}

}
